This script will REST_ENABLE objects in F1_ACCESS schema that allow you
to replicate the functionality that ergast has. E.g you will be able
to get the data from the different views as REST calls using Oracle Rest Data Services.

To enable AUTOREST look at the ENABLE script.
To disable AUTOREST run the DISABLE script.
